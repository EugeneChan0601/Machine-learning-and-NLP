#!/usr/bin/env python
import re, random, math, collections, itertools
from nltk.stem import WordNetLemmatizer

PRINT_ERRORS=1

#------------- Function Definitions ---------------------


def readFiles(sentimentDictionary,sentencesTrain,sentencesTest,sentencesNokia):

    #reading pre-labeled input and splitting into lines
    posSentences = open('rt-polarity.pos', 'r', encoding="ISO-8859-1")
    posSentences = re.split(r'\n', posSentences.read())

    negSentences = open('rt-polarity.neg', 'r', encoding="ISO-8859-1")
    negSentences = re.split(r'\n', negSentences.read())

    posSentencesNokia = open('nokia-pos.txt', 'r')
    posSentencesNokia = re.split(r'\n', posSentencesNokia.read())

    negSentencesNokia = open('nokia-neg.txt', 'r', encoding="ISO-8859-1")
    negSentencesNokia = re.split(r'\n', negSentencesNokia.read())
 
    posDictionary = open('positive-words.txt', 'r', encoding="ISO-8859-1")
    posWordList = re.findall(r"[a-z\-]+", posDictionary.read())

    negDictionary = open('negative-words.txt', 'r', encoding="ISO-8859-1")
    negWordList = re.findall(r"[a-z,1-9\-]+", negDictionary.read())

    for i in posWordList:
        sentimentDictionary[i] = 1
    for i in negWordList:
        sentimentDictionary[i] = -1

    #create Training and Test Datsets:
    #We want to test on sentences we haven't trained on, to see how well the model generalses to previously unseen sentences

  #create 90-10 split of training and test data from movie reviews, with sentiment labels    
    for i in posSentences:
        if random.randint(1,10)<2:
            sentencesTest[i]="positive"
        else:
            sentencesTrain[i]="positive"

    for i in negSentences:
        if random.randint(1,10)<2:
            sentencesTest[i]="negative"
        else:
            sentencesTrain[i]="negative"

    #create Nokia Datset:
    for i in posSentencesNokia:
            sentencesNokia[i]="positive"
    for i in negSentencesNokia:
            sentencesNokia[i]="negative"

#----------------------------End of data initialisation ----------------#

#calculates p(W|Positive), p(W|Negative) and p(W) for all words in training data
def trainBayes(sentencesTrain, pWordPos, pWordNeg, pWord):
    posFeatures = [] # [] initialises a list [array]
    negFeatures = [] 
    freqPositive = {} # {} initialises a dictionary [hash function]
    freqNegative = {}
    dictionary = {}
    posWordsTot = 0
    negWordsTot = 0
    allWordsTot = 0

    #iterate through each sentence/sentiment pair in the training data
    for sentence, sentiment in sentencesTrain.items():
        wordList = re.findall(r"[\w']+", sentence)
        
        for word in wordList: #calculate over unigrams
            allWordsTot += 1 # keeps count of total words in dataset
            if not (word in dictionary):
                dictionary[word] = 1
            if sentiment=="positive" :
                posWordsTot += 1 # keeps count of total words in positive class

                #keep count of each word in positive context
                if not (word in freqPositive):
                    freqPositive[word] = 1
                else:
                    freqPositive[word] += 1    
            else:
                negWordsTot+=1# keeps count of total words in negative class
                
                #keep count of each word in positive context
                if not (word in freqNegative):
                    freqNegative[word] = 1
                else:
                    freqNegative[word] += 1

    for word in dictionary:
        #do some smoothing so that minimum count of a word is 1
        if not (word in freqNegative):
            freqNegative[word] = 1
        if not (word in freqPositive):
            freqPositive[word] = 1

        # Calculate p(word|positive)
        pWordPos[word] = freqPositive[word] / float(posWordsTot)

        # Calculate p(word|negative) 
        pWordNeg[word] = freqNegative[word] / float(negWordsTot)

        # Calculate p(word)
        pWord[word] = (freqPositive[word] + freqNegative[word]) / float(allWordsTot) 

#---------------------------End Training ----------------------------------

#implement naive bayes algorithm
#INPUTS:
#  sentencesTest is a dictonary with sentences associated with sentiment 
#  dataName is a string (used only for printing output)
#  pWordPos is dictionary storing p(word|positive) for each word
#     i.e., pWordPos["apple"] will return a real value for p("apple"|positive)
#  pWordNeg is dictionary storing p(word|negative) for each word
#  pWord is dictionary storing p(word)
#  pPos is a real number containing the fraction of positive reviews in the dataset
def tesBayes(sentencesTest, dataName, pWordPos, pWordNeg, pWord,pPos):
    pNeg=1-pPos

    #These variables will store results
    total=0
    correct=0
    totalpos=0
    totalpospred=0
    totalneg=0
    totalnegpred=0
    correctpos=0
    correctneg=0

    #for each sentence, sentiment pair in the dataset
    for sentence, sentiment in sentencesTest.items():
        wordList = re.findall(r"[\w']+", sentence)#collect all words

        pPosW=pPos
        pNegW=pNeg

        for word in wordList: #calculate over unigrams
            if word in pWord:
                if pWord[word]>0.00000001:
                    pPosW *=pWordPos[word]
                    pNegW *=pWordNeg[word]

        prob=0;            
        if pPosW+pNegW >0:
            prob=pPosW/float(pPosW+pNegW)


        total+=1
        if sentiment=="positive":
            totalpos+=1
            if prob>0.5:
                correct+=1
                correctpos+=1
                totalpospred+=1
            else:
                correct+=0
                totalnegpred+=1
                if PRINT_ERRORS:
                    print ("ERROR (pos classed as neg %0.2f):" %prob + sentence)
        else:
            totalneg+=1
            if prob<=0.5:
                correct+=1
                correctneg+=1
                totalnegpred+=1
            else:
                correct+=0
                totalpospred+=1
                if PRINT_ERRORS:
                    print ("ERROR (neg classed as pos %0.2f):" %prob + sentence)

    calculate_metrics(correct,total,correctpos,totalpospred,totalpos,correctneg,totalnegpred,totalneg)
 
 
# TODO for Step 2: Add some code here to calculate and print: (1) accuracy; (2) precision and recall for the positive class;
# (3) precision and recall for the negative class; (4) F1 score;
def calculate_metrics(correct,total,correctpos,totalpospred,totalpos,correctneg,totalnegpred,totalneg):
    # Accuracy
    Accuracy = (100.0 * correct) / total
    print('Accuracy for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correct) / total, correct, total))

    # Precision of positive
    precisionPos = (100.0 * correctpos) / totalpospred
    print('Precision of positive for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctpos) / totalpospred, correctpos, totalpospred))

    # Recall of positive
    recallPos = (100.0 * correctpos) / totalpos
    print('Recall of positive for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctpos) / totalpos, correctpos, totalpos))

    # F-measure of positive
    fPos = (2*precisionPos*recallPos)/(precisionPos+recallPos)
    print('F-measure of positive for test data: %5.2f%% ' % \
          ((2*precisionPos*recallPos)/(precisionPos+recallPos)))

    # Precision of negative
    precisionNeg = (100.0 * correctneg) / totalnegpred
    print('Precision of negative for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctneg) / totalnegpred, correctneg, totalnegpred))

    # Recall of negative
    recallNeg = (100.0 * correctneg) / totalneg
    print('Recall of negative for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctneg) / totalneg, correctneg, totalneg))

    # F-measure of negative
    fNeg = (2 * precisionNeg * recallNeg) / (precisionNeg + recallNeg)
    print('F-measure of negative for test data: %5.2f%% ' % \
          ((2 * precisionNeg * recallNeg) / (precisionNeg + recallNeg)))

    print();


# This is a simple classifier that uses a sentiment dictionary to classify 
# a sentence. For each word in the sentence, if the word is in the positive 
# dictionary, it adds 1, if it is in the negative dictionary, it subtracts 1. 
# If the final score is above a threshold, it classifies as "Positive", 
# otherwise as "Negative"
def tesDictionary(sentencesTest, dataName, sentimentDictionary, threshold):
    total=0
    correct=0
    totalpos=0
    totalneg=0
    totalpospred=0
    totalnegpred=0
    correctpos=0
    correctneg=0

    for sentence, sentiment in sentencesTest.items():
        Words = re.findall(r"[\w']+", sentence)
        score=0
        for word in Words:
            if word in sentimentDictionary:
               score+=sentimentDictionary[word]
 
        total+=1
        if sentiment=="positive":
            totalpos+=1
            if score>=threshold:
                correct+=1
                correctpos+=1
                totalpospred+=1
            else:
                correct+=0
                totalnegpred+=1
        else:
            totalneg+=1
            if score<threshold:
                correct+=1
                correctneg+=1
                totalnegpred+=1
            else:
                correct+=0
                totalpospred+=1

    Accuracy = (100.0 * correct) / total
    print('Accuracy for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correct) / total, correct, total))

    # Precision of positive
    precisionPos = (100.0 * correctpos) / totalpospred
    print('Precision of positive for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctpos) / totalpospred, correctpos, totalpospred))

    # Recall of positive
    recallPos = (100.0 * correctpos) / totalpos
    print('Recall of positive for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctpos) / totalpos, correctpos, totalpos))

    # F-measure of positive
    fPos = (2 * precisionPos * recallPos) / (precisionPos + recallPos)
    print('F-measure of positive for test data: %5.2f%% ' % \
          ((2 * precisionPos * recallPos) / (precisionPos + recallPos)))

    # Precision of negative
    precisionNeg = (100.0 * correctneg) / totalnegpred
    print('Precision of negative for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctneg) / totalnegpred, correctneg, totalnegpred))

    # Recall of negative
    recallNeg = (100.0 * correctneg) / totalneg
    print('Recall of negative for test data: %5.2f%% (%d / %d)' % \
          ((100.0 * correctneg) / totalneg, correctneg, totalneg))

    # F-measure of negative
    fNeg = (2 * precisionNeg * recallNeg) / (precisionNeg + recallNeg)
    print('F-measure of negative for test data: %5.2f%% ' % \
          ((2 * precisionNeg * recallNeg) / (precisionNeg + recallNeg)))

    print();
 
    
# TODO for Step 5: Add some code here to calculate and print: (1) accuracy; (2) precision and recall for the positive class; 
# (3) precision and recall for the negative class; (4) F1 score;
def tesImproved(sentencesTest, dataName,  threshold):
    total = 0
    correct = 0
    totalpos = 0
    totalpospred = 0
    totalneg = 0
    totalnegpred = 0
    correctpos = 0
    correctneg = 0

    denyWordList = ["not","cannot","can't","don't","n't","does n't","no","'t","but","But","However","however"]
    diminisherList = ["somewhat","barely","rarely","nearly","solely","fairly","slightly","probably","relatively"]
    intensifierList = ["definitely","very","extremely","truly","fully","really","highly","overly","impossibly","utterly"]


    posDictionary = open('positive-words.txt', 'r', encoding="ISO-8859-1")
    posWordList = re.findall(r"[a-z\-]+", posDictionary.read())

    negDictionary = open('negative-words.txt', 'r', encoding="ISO-8859-1")
    negWordList = re.findall(r"[a-z,1-9\-]+", negDictionary.read())

    for sentence, sentiment in sentencesTest.items():

        sentiment_word_location = 0
        current_location = 0

        Words = re.findall(r"[a-z,1-9\!]+", sentence)
        score = 0
        posCount = 0
        negCount = 0
        symbol_mark = 0

        for word in Words:
            word = lemmatize(word)
            if word in posWordList:
                # score += 2
                posCount += 2
                c = 0
                for w in Words[sentiment_word_location:current_location]:
                    if w in diminisherList:
                        posCount -= 1
                    elif w in intensifierList:
                        posCount += 1
                    elif w in denyWordList:
                        c += 1
                    if judgeodd(c)== 'odd': # judege the number of negation words
                        posCount *= -1
                        # posCount1 *= -1
                sentiment_word_location = current_location + 1

            elif word in negWordList:
                # score -= 2
                negCount += 2
                c = 0
                for w in Words[sentiment_word_location:current_location]:
                    if w in diminisherList:
                        negCount += 1
                    elif w in intensifierList:
                       negCount -= 1
                    elif w in denyWordList:
                        c += 1
                    if judgeodd(c)== 'odd':
                        negCount *= -1
                        # posCount1 *= -1
                sentiment_word_location = current_location + 1

            elif word =="!":
                for w2 in Words[::-1]:
                    if w2 in posWordList:
                        for w3 in Words[Words.index(w2):Words.index(w2)+4]:
                            if w3 not in denyWordList:
                                symbol_mark += 2
                            else:
                                symbol_mark -= 2
                    elif w2 in negWordList:
                        for w3 in Words[Words.index(w2):Words.index(w2)+4]:
                            if w3 not in denyWordList:
                                symbol_mark -= 2
                            else:
                                symbol_mark += 2
                    break;
            current_location += 1
            score = posCount-negCount+symbol_mark

        total += 1

        if sentiment == "positive":
            totalpos += 1
            if score >= threshold:
                correct += 1
                correctpos += 1
                totalpospred += 1
            else:
                correct += 0
                totalnegpred += 1
        else:
            totalneg += 1
            if score < threshold:
                correct += 1
                correctneg += 1
                totalnegpred += 1
            else:
                correct += 0
                totalpospred += 1

    calculate_metrics(correct, total, correctpos, totalpospred, totalpos, correctneg, totalnegpred, totalneg)

def judgeodd(num):
    if(num%2==0):
        return 'even'
    else:
        return 'odd'

lemmatizer = WordNetLemmatizer()
def lemmatize(word):
    return lemmatizer.lemmatize(word)

#Print out n most useful predictors
def mostUseful(pWordPos, pWordNeg, pWord, n):
    predictPower={}
    for word in pWord:
        if pWordNeg[word]<0.0000001:
            predictPower=1000000000
        else:
            predictPower[word]=pWordPos[word] / (pWordPos[word] + pWordNeg[word])
            
    sortedPower = sorted(predictPower, key=predictPower.get)
    head, tail = sortedPower[:n], sortedPower[len(predictPower)-n:]
    print ("NEGATIVE:")
    print (head)
    print ("\nPOSITIVE:")
    print (tail)



#---------- Main Script --------------------------


sentimentDictionary={} # {} initialises a dictionary [hash function]
sentencesTrain={}
sentencesTest={}
sentencesNokia={}

#initialise datasets and dictionaries
readFiles(sentimentDictionary,sentencesTrain,sentencesTest,sentencesNokia)

pWordPos={} # p(W|Positive)
pWordNeg={} # p(W|Negative)
pWord={}    # p(W) 

#build conditional probabilities using training data
trainBayes(sentencesTrain, pWordPos, pWordNeg, pWord)

#run naive bayes classifier on datasets
print ("Naive Bayes")
# tesBayes(sentencesTrain,  "Films (Train Data, Naive Bayes)\t", pWordPos, pWordNeg, pWord,0.5)
tesBayes(sentencesTest,  "Films  (Test Data, Naive Bayes)\t", pWordPos, pWordNeg, pWord,0.5)
# tesBayes(sentencesNokia, "Nokia   (All Data,  Naive Bayes)\t", pWordPos, pWordNeg, pWord,0.7)

#run sentiment dictionary based classifier on datasets
# print("Dictionary-based system")
# print("Film train data")
# tesDictionary(sentencesTrain,  "Films (Train Data, Rule-Based)\t", sentimentDictionary, 0)
# print("Film test data")
# tesDictionary(sentencesTest,  "Films  (Test Data, Rule-Based)\t",  sentimentDictionary, 0)
# print("Nokia all data")
# tesDictionary(sentencesNokia, "Nokia   (All Data, Rule-Based)\t",  sentimentDictionary, 0)

# print("Rule-based system")
# print("Film train data")
# tesImproved(sentencesTrain, "Films (Train Data, Rule-Based)\t", 0)
# print("Film test data")
# tesImproved(sentencesTest, "Films  (Test Data, Rule-Based)\t", 0)
# print("Nokia all data")
# tesImproved(sentencesNokia, "Nokia   (All Data, Rule-Based)\t", 0)


# print most useful words
mostUseful(pWordPos, pWordNeg, pWord, 50)



